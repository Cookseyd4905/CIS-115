// Dustin Cooksey

// C4A2

// 07-02-2019

// This program takes an amount of change and returns whether that
// amount equals one dollar or not.
package c4a2_dollargame_dustincooksey;
import java.util.Scanner;
public class C4A2_DollarGame_DustinCooksey 
{

   
    public static void main(String[] args) 
    {
        displayInfo();
       Scanner k = new Scanner(System.in);
       System.out.print("Please enter the amount quarters: ");
       int quarters = k.nextInt();
       int totOfQuarters = quarters * 25;
       System.out.print("Please enter the amount of dimes: ");
       int dimes = k.nextInt();
       int totOfDimes = dimes * 10;
       System.out.print("Please enter the amount of nickels: ");
       int nickels = k.nextInt();
       int totOfNickels = nickels * 5;
       System.out.print("Please enter the amount of pennies: ");
       int pennies = k.nextInt();
       int finalTotal = (totOfNickels + totOfDimes + totOfQuarters + pennies);
       
       if (finalTotal == 100)
           System.out.println("Congratulations! You made a dollar!");
       else if (finalTotal < 100)
           System.out.println("You didn't have enough change");
       else 
           System.out.println("You had too much change");
       
    }
    public static void displayInfo()
    {
        System.out.println("Dustin Cooksey");
        System.out.println("CIS-115-1001");
    }
    
}
